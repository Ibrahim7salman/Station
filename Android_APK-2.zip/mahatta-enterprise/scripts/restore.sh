#!/bin/sh
set -eu
if [ "$#" -ne 1 ]; then echo "Usage: $0 backups/file.dump"; exit 2; fi
set -a
. ./.env
set +a
echo "WARNING: this replaces the current database contents."
printf "Type RESTORE to continue: "
read answer
[ "$answer" = "RESTORE" ] || exit 1
docker compose exec -T db pg_restore -U "${POSTGRES_USER:-mahatta}" -d "${POSTGRES_DB:-mahatta}" --clean --if-exists < "$1"
